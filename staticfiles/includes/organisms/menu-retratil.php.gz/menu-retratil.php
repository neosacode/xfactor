<div class="back-menu-2"id="item1">
	<div class="container">
		<div class="menu-2">
			<ul>
				<li><a href=""><img src="img/logo-6.png" alt=""><span>Carteiras</span></a></li>
				<li><a href=""><img src="img/logo-7.png" alt=""><span>Extratos</span></a></li>
				<li><a href=""><img src="img/logo-8.png" alt=""><span>Pay Bill</span></a></li>
				<li><a href=""><img src="img/logo-9.png" alt=""><span>Phone Recharge</span></a></li>
			</ul>
		</div>
	</div>
</div>