	<header>
		<div class="back-menu">
			<div class="container-fluid">
				<div class="logo">
					<img src="img/logo.png" alt="">
				</div>

				<div class="toggle-1">
					<a onclick="mostra('item1');"><i class="fa fa-bars"></i></a>
				</div>


				<div class="toggle-2">
					<a onclick="mostra('item1');"><i class="fa fa-times"></i></a>
				</div>


				<div class="menu">
					<ul>
						<li><a href="index.php"><img src="img/logo-1.png" alt=""><span>Dashboard</span></a></li>
						<li><a href="investing.php"><img src="img/logo-2.png" alt=""><span>Investing Plans</span></a></li>
						<li><a href="credit.php"><img src="img/logo-3.png" alt=""><span>Credit Line</span></a></li>
						<li><a href="statement.php"><img src="img/logo-4.png" alt=""><span>Statement</span></a></li>
						<li><a href="customers.php"><img src="img/logo-5.png" alt=""><span>Customers</span></a></li>
					</ul>
				</div>
				<div class="settings">
					<ul>
						<li><a href=""><img src="img/foto.png" alt=""><span>Nome Sobrenome</span><i class="fa fa-angle-down"></i></a></li>
						<li><a href=""><img src="img/settings.png" alt=""></a></li>
					</ul>
				</div>
			</div>
		</div>
	</header>